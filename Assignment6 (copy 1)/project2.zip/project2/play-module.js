/* In this module, create three classes: Play, Act, and Scene. */

