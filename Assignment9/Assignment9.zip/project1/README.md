

Setup database connection details in includes/travel-config.inc.php 
