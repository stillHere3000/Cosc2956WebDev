<?php

include 'includes/travel-config.inc.php';



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Chapter 14</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" href="css/styles.css" />

</head>

<body>                                    
   <main class="detail">
      <div>
         image here
      </div>
      <div>
         <h1>title here</h1>
         <h3>city, country</h3>
         <p>description</p>
         <div class="box">
            <h3>Creator</h3>

         </div>
         
         <div class="box">
            <h3>Camera</h3>

         </div>
         <div class="box">
            <h3>Colors</h3>

         </div>
      </div>
   </main>
</body>

</html>