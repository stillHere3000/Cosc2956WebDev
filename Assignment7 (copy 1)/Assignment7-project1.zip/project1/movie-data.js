
const movieData = [
    {   id: 71, title: "Parasite", tagline: "Act like you own the place",
        poster: "/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg", runtime: 133, tmdbID: 496243
    },      
   

    {   id: 229, title: "The Seventh Seal", tagline: "Challenging Death to a chess match",
        poster: "/wcZ21zrOsy0b52AfAF50XpTiv75.jpg", runtime: 96, tmdbID: 490
    },
    {   id: 30, title: "La Dolce Vita", tagline: "The world's most talked about movie today",
        poster: "/mZJ25Th65B2KXM57uIiEzO3Aw81.jpg", runtime: 176, tmdbID: 439
    },     
    {   id: 15, title: "The Battle of Algiers", tagline: "The Revolt that Stirred the World!",
        poster: "/9fHkCuYEKsu7j0xsI2HbBvlZNZc.jpg", runtime: 121, tmdbID: 17295
    },  

    {   id: 128, title: "Emma", tagline: "In 1800s England, a well-meaning but selfish young woman meddles in the love lives of her friends.",
        poster: "/sm8iVzA7kRp0d4BSIsgXjsSBMKV.jpg", runtime: 124, tmdbID: 556678
    },    
 
    {   id: 65, title: "Nebraska", tagline: "Life's not about winning or losing. It's about how you get there in the end.",
        poster: "/3WdcebeFY1ProN3MxKuaT78CK8w.jpg", runtime: 115, tmdbID: 129670
    },  
    {   id: 21, title: "Miller's Crossing", tagline: "Up is down, black is white, and nothing is what it seems.",
    poster: "/ab3pnsTKp3BgcAFy0FgWBFBg9FL.jpg", runtime: 115, tmdbID: 379
    },  
    {   id: 11, title: "Mary Poppins", tagline: "It's supercalifragilisticexpialidocious!",
        poster: "/ei8hhYCMfURfPOXKBnyl61be2iV.jpg", runtime: 139, tmdbID: 433
    },      
    {   id: 2, title: "La passion de Jeanne d'Arc", tagline: "An Immortal Screen Classic that will live Forever!",
        poster: "/8OYGtQlO8k9PcOm49apV62eVJQo.jpg", runtime: 114, tmdbID: 780
    },  
    {   id: 95, title: "Mulholland Drive", tagline: "An actress longing to be a star. A woman searching for herself. Both worlds will collide... on Mulholland Drive",
        poster: "/tVxGt7uffLVhIIcwuldXOMpFBPX.jpg", runtime: 147, tmdbID: 1018
    },   
    {   id: 14, title: "Be Cool", tagline: "Everyone is looking for the next big hit",
        poster: "/ekKCH7Zkb5ZTr1f1AczZY23FH.jpg", runtime: 118, tmdbID: 4551
    },     
    {   id: 13, title: "American Beauty", tagline: "Look Closer",
        poster: "/wby9315QzVKdW9BonAefg8jGTTb.jpg", runtime: 122, tmdbID: 14
    },       
    {   id: 102, title: "The Grand Budapest Hotel", tagline: "A murder case of Madam D. ",
        poster: "/w1TwIEJ3RBKmXdCMYkeqORTHZcP.jpg", runtime: 100, tmdbID: 120467
    },
    {   id: 180, title: "Dunkirk", tagline: "Survival is Victory",
        poster: "/ebSnODDg9lbsMIaWg2uAbjn7TO5.jpg", runtime: 107, tmdbID: 374720
    },
    {   id: 212, title: "Danton", tagline: "Danton and Robespierre were close friends and fought together but ...",
        poster: "/fR3MujUz2AX3iFWKlLEDEKvoW4L.jpg", runtime: 136, tmdbID: 4202
    }                                                    
];